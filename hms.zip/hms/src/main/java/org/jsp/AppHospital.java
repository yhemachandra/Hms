package org.jsp;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class AppHospital
{
	public static void main(String[] args) 
	{
		while(true) 
		{
			System.out.println("select option");
			System.out.println("1)patient details");
			System.out.println("2)doc details");
		
			while(true) 
			{
			System.out.println("Select option");
			System.out.println("1)Register");
			System.out.println("2)Update disease by id");
			System.out.println("3)Update age by phone number");
			System.out.println("4)view all");
			System.out.println("5)view patient by phone number");
			System.out.println("6)search patients by disease");
			System.out.println("7)Search patient by name");
			System.out.println("8)Delete patient recored by phone no and name");
			
			switch(sc.nextInt())
			{
			case 1:
				register();
				break;
			
			case 2:
				Updatebyid();
				break;
					
			case 3:
				updateage();
					break;
			case 4:
				viewall();
				break;
				
			case 5:
				viewpatient();
				break;
					
			case 6:
				searchbydisease();
				break;
					
			case 7:
				searchbyname();
				break;
					
				case 8:
				deletebyphoneno();
				break;
					
				default:System.err.println("invalid choice");
					break;
			}	
		}
	}
	
	
	}

	static Scanner sc = new Scanner(System.in);
	static void register()
	{
			System.out.println("enter id: ");
			int id=sc.nextInt();
			
			System.out.println("enter Name: ");
			String name=sc.next();
			
			System.out.println("enter age: ");
			int age=sc.nextInt();
			
			System.out.println("enter phone number ");
			long phoneno = sc.nextLong();
			
			System.out.println("enter disease: ");
			String disease=sc.next();
			
			System.out.println("enter admitied date: ");
			String date=sc.next();
			
			try 
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","root");
				PreparedStatement ps=con.prepareStatement("insert into patient values(?,?,?,?,?,?)");
				ps.setInt(1, id);
				ps.setString(2,name);
				ps.setInt(3, age);
				ps.setLong(4,phoneno);
				ps.setString(5,disease);
				ps.setString(6,date);
				
				int row=ps.executeUpdate();
				System.out.println(row+ " : row Inserted...");
				
				ps.close();
				con.close();	
			
			} 
			catch (ClassNotFoundException | SQLException e)
			{
		
				e.printStackTrace();
			}
			
	}

	 static void Updatebyid() 
	 {
		 try 
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","root");
				
				PreparedStatement ps=con.prepareStatement("update patient set disease=? where id=?");
				
				Scanner sc=new Scanner(System.in);
				System.out.println("enter disease to update");
				String name = sc.next();
				
				System.out.println("enter id: ");
				int idr = sc.nextInt();
				
				ps.setString(1,disease);
				ps.setInt(2,id);
				
				int row = ps.executeUpdate();
				System.out.println(row + " : row affected....");
				
				ps.close();
				con.close();
				System.out.println("********done*******");
			}
			catch(ClassNotFoundException | SQLException e)
			{
				e.printStackTrace();
			}		
	}
	 static void updateage() 
	 {
		 try 
			{
				Class.forName("com.mysql.cj.jdbc.Driver");
				
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","root");
				
				PreparedStatement ps=con.prepareStatement("update patient set age=? where phoneno=?");
				
				Scanner sc=new Scanner(System.in);
				System.out.println("enter age: ");
				int age=sc.nextInt();
				
				System.out.println("enter phoeno: ");
				long phoneno = sc.nextLong();
				
				ps.setInt(1,age);
				ps.setLong(2,phoneno);
				
				int row = ps.executeUpdate();
				System.out.println(row + " : row affected....");
				
				ps.close();
				con.close();
				System.out.println("********done*******");
			}
			catch(ClassNotFoundException | SQLException e)
			{
				e.printStackTrace();
			}		
	 }
	 static void viewall() {
		 try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","root");
				Statement s = con.createStatement();
				boolean b=s.execute("select * from patient;");
				if(b==true) {
					ResultSet rs = s.getResultSet();
					int c=1;
					while(rs.next()) {
						System.out.print(rs.getInt(1)+"\t");
						System.out.print(rs.getString(2)+"\t");
						System.out.print(rs.getInt(3)+"\t");
						System.out.print(rs.getLong(4)+"\t");
						System.out.print(rs.getString(5)+"\t");
						System.out.println(rs.getString(6));
					}
					rs.close();
				}
				s.close();
				con.close();
				
			} catch (ClassNotFoundException | SQLException e) {
				
				e.printStackTrace();
			}
	 }
	 static void viewpatient() {
		 try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","root");
				PreparedStatement ps=con.prepareStatement("select * from patient where phoneno=?");
				System.out.println("enter phoneno:  ");
				Scanner sc = new Scanner(System.in);
				ps.setLong(1, sc.nextLong());
				ResultSet rs = ps.executeQuery();

					while(rs.next()) 
					{
						System.out.print(rs.getInt(1)+"\t");
						System.out.print(rs.getString(2)+"\t");
						System.out.print(rs.getInt(3)+"\t");
						System.out.print(rs.getLong(4)+"\t");
						System.out.print(rs.getString(5)+"\t");
						System.out.println(rs.getString(6));
						
					}
					rs.close();
					ps.close();

				ps.close();
				con.close();	
			} catch (ClassNotFoundException | SQLException e) {
				
				e.printStackTrace();
			}
			
		}
	 static void searchbydisease()
	 {
			 System.out.println("Enter Disease");
			 String disease = sc.next();
			 Connection con = null;
			 PreparedStatement ps =null;
			 ResultSet rs=null;
			 try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","root");
					ps = con.prepareStatement("select * from patient where disease=?");
					ps.setString(1, disease);
					rs = ps.executeQuery();
					while(rs.next())
					{
						System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getInt(3)+"\t"+rs.getLong(4)+"\t"+rs.getString(5)+"\t"+rs.getDate(6));
					}
					
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally {
					if(rs != null)
					{
						try {
							rs.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					if(ps != null)
					{
						try {
							ps.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					if(con != null)
					{
						try {
							con.close();
						} catch (SQLException e) {
							
							e.printStackTrace();
						}
					}
				}
				}
	
	 static void searchbyname() {
			 System.out.println("Enter phone number");
			 long phoneNo = sc.nextLong();
			 Connection con = null;
			 PreparedStatement ps =null;
			 ResultSet rs=null;
			 try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","root");
					ps = con.prepareStatement("select * from patient where phoneno=?");
					ps.setLong(1, phoneNo);
					rs = ps.executeQuery();
					while(rs.next())
					{
						System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getInt(3)+"\t"+rs.getLong(4)+"\t"+rs.getString(5)+"\t"+rs.getDate(6));
					}
					
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally {
					if(rs != null)
					{
						try {
							rs.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					if(ps != null)
					{
						try {
							ps.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					if(con != null)
					{
						try {
							con.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
				
	 }
	 static void deletebyphoneno() {
		 try
			{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/hospital","root","root");
			PreparedStatement ps=con.prepareStatement("delete from patient where phoneno=?");
			
			Scanner sc=new Scanner(System.in);
			System.out.println("enter phone to delete: ");
			long phoneno = sc.nextLong();
			ps.setLong(1, phoneno);
			int row=ps.executeUpdate();
			System.out.println(row+": Rows Affected......");
			ps.close();
			con.close();
			System.out.println("Done.......");
			}
			catch(ClassNotFoundException | SQLException e)
			{
				e.printStackTrace();
			}
		}
	 
} 

